Discord-Typing-Sites-RPC.jar　取扱説明書

【概要】
Discord-Typing-Sites-RPC.jar //本体ファイル
Discord-Typing-Sites-RPC.vbs //起動補助ファイル

Javaインストール済みの環境でDiscord-Typing-Sites-RPC.jarを直接起動すると
Discord上に表示されるタイピングサイト・ソフトの表示内容が文字化けしてしまうので
vbsファイル経由でjarファイルを起動することで文字化けを回避しています。


【導入手順】
➀ 解凍して出てきたDiscord Typing Sites RPC Jarを適当なフォルダに配置します。(例: タイピングツール置き場 や C:\Program Filesフォルダ等の好きなフォルダに配置)

➁ Discord-Typing-Sites-RPC.vbsファイルを右クリック＞ショートカットの作成(S)で[Discord-Typing-Sites-RPC - ショートカット]ファイルを作成します。

➂ PC のエクスプローラーのアドレス欄に shell:startup と入力し表示されたフォルダ内に [Discord-Typing-Sites-RPC - ショートカット] を移動します。

➃ (初回のみ!!) 先程フォルダ内に移動した ショートカットファイルをダブルクリックして起動 または PCの再起動 をします。(次の起動時から自動的に起動します。)

(注)vbsファイルからjarファイルを実行するため、[Discord-Typing-Sites-RPC.jar]ファイル名を変更すると起動しなくなります。